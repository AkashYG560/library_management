#include <stdio.h>
#include <string.h>

int main() {
    char library[10][50];  // Increased the size to accommodate longer book titles
    int numBooks = 0;
    int choice = 0;

    printf("\nLibrary Management System\n");

    while (choice != 3) {
        printf(" Press 1. Add Book\n");
        printf(" Press 2. Search Book\n");
        printf(" Press 3. Exit\n");
        scanf("%d", &choice);

        if (choice == 1) {
            if (numBooks < 10) {
                printf("\nEnter the title of the book: ");
                scanf(" %[^\n]", library[numBooks]);
                numBooks++;
                printf("Book added successfully!\n");
            } else {
                printf("The library is full.\n");
            }
        } else if (choice == 2) {
            if (numBooks > 0) {
                char searchTitle[50];
                int found = 0;

                printf("\nEnter the title to search: ");
                scanf(" %[^\n]", searchTitle);

                for (int i = 0; i < numBooks; i++) {
                    if (strstr(library[i], searchTitle) != NULL) {
                        printf("Book found: %s\n", library[i]);
                        found = 1;
                        break;
                    }
                }

                if (!found) {
                    printf("Book not found.\n");
                }
            } else {
                printf("No books in the library to search.\n");
            }
        } else if (choice != 3) {
            printf("Invalid choice. Please enter 1 to add a book, 2 to search, or 3 to exit.\n");
        }
    }

    return 0;
}
